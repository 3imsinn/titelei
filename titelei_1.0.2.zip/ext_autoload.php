<?php

$libraryClassesPath = \Typo3\CMS\Core\Utility\ExtensionManagementUtility::extPath('titelei').'Ressources/Private/Library';
return array('EPUB' => $libraryClassesPath.'epub.php',
);

?>
